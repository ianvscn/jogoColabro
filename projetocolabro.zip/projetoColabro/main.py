import funcoes
import janela

# apresentação do jogo

# armazena se player ganhou ou perdeu
execucao = janela

# analisa o resultado_final responde de acordo
